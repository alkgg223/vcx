package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws an item as a big rotating 3D model inside a GUI. */
public final class GunPreview {
    private GunPreview() {}

    public static void draw(GuiGraphics g, ItemStack stack, float cx, float cy, float size, float yaw, float pitch) {
        if (stack.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(stack.getItem() instanceof GunItem)) {
            g.pose().pushPose();
            g.pose().translate(cx - size / 2f, cy - size / 2f, 0);
            float k = size / 16f;
            g.pose().scale(k, k, 1f);
            g.renderItem(stack, 0, 0);
            g.pose().popPose();
            return;
        }
        BakedModel model = mc.getItemRenderer().getModel(stack, mc.level, mc.player, 0);
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(cx, cy, 150f);
        ps.scale(size, -size, size);
        ps.mulPose(Axis.XP.rotationDegrees(pitch));
        ps.mulPose(Axis.YP.rotationDegrees(yaw));
        com.mojang.blaze3d.platform.Lighting.setupFor3DItems();
        mc.getItemRenderer().render(stack, ItemDisplayContext.NONE, false, ps, g.bufferSource(),
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, model);
        g.flush();
        com.mojang.blaze3d.platform.Lighting.setupForFlatItems();
        ps.popPose();
    }

    public static void small(GuiGraphics g, net.minecraft.client.gui.Font font, String text, int x, int y, int color, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, color, false);
        g.pose().popPose();
    }
}
