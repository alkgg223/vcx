package com.example.gunsmod;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class GunCustomizerMenu extends AbstractContainerMenu {
    private final Container gunSlot = new SimpleContainer(1);
    private final ContainerLevelAccess access;

    public GunCustomizerMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(GunsMod.CUSTOMIZER_MENU.get(), id);
        this.access = access;
        this.addSlot(new Slot(gunSlot, 0, 10, 30) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.getItem() instanceof GunItem;
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(inv, c + r * 9 + 9, 10 + c * 18, 152 + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(inv, c, 10 + c * 18, 210));
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index == 0) {
            if (!this.moveItemStackTo(stack, 1, 37, true)) return ItemStack.EMPTY;
        } else {
            if (!(stack.getItem() instanceof GunItem) || !this.moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GunsMod.CUSTOMIZER.get());
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.access.execute((level, pos) -> this.clearContainer(player, this.gunSlot));
    }

    private boolean pay(Player p, Item a, int na, Item b, int nb) {
        if (p.getAbilities().instabuild) return true;
        if (WorkbenchRecipes.count(p, a) < na || WorkbenchRecipes.count(p, b) < nb) return false;
        WorkbenchRecipes.consume(p, a, na);
        WorkbenchRecipes.consume(p, b, nb);
        return true;
    }

    /** Buttons 0..6 = paint, 10..12 = scope (0 none, 1 red dot, 2 4x scope). */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        ItemStack st = gunSlot.getItem(0);
        if (!(st.getItem() instanceof GunItem g)) return false;
        int paint = GunItem.getPaint(st);
        int scope = GunItem.getScope(st);
        if (id >= 0 && id < Paints.COUNT) {
            paint = id;
        } else if (id >= 10 && id <= 12) {
            int ns = id - 10;
            if (g.type.scoped) {
                player.displayClientMessage(Component.literal("This weapon already has a built-in scope"), true);
                return false;
            }
            if (ns != scope) {
                if (ns == 1 && !pay(player, Items.IRON_INGOT, 2, Items.REDSTONE, 1)) {
                    player.displayClientMessage(Component.literal("Not enough materials"), true);
                    return false;
                }
                if (ns == 2 && !pay(player, Items.IRON_INGOT, 4, Items.DIAMOND, 1)) {
                    player.displayClientMessage(Component.literal("Not enough materials"), true);
                    return false;
                }
                scope = ns;
            }
        } else {
            return false;
        }
        GunItem.setCosmetics(st, paint, scope);
        gunSlot.setChanged();
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.4f, 1.8f);
        return true;
    }
}
